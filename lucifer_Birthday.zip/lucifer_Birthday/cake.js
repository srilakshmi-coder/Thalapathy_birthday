const showCake = () => {
    document.querySelector('#cake-holder').classList.add('done')
}